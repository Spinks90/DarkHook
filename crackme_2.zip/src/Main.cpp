/*
Name:			CrackMe_1
Description:	Simple vulnerable password stored in memory.
*/


#include <iostream>
#include <Windows.h>

int main(void)
{
	using namespace std;
	SetConsoleTitleA("CrackMe_2 by PoZHx");
	HANDLE hConsoleOut = GetStdHandle(STD_OUTPUT_HANDLE);

	const char szPassword[] = "mypass123";
	char szUserGuess[50] = {0};

	while(1)
	{
		SetConsoleTextAttribute(hConsoleOut, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
		cout << "Please input the string password:\t";
		cin >> szUserGuess;
		if(cin.bad() || cin.fail())
		{
			SetConsoleTextAttribute(hConsoleOut, FOREGROUND_RED | FOREGROUND_INTENSITY);
			cout << "Bad input.\n";
			cin.sync();
			cin.clear();
			continue;
		}
		if (strcmp(szUserGuess, szPassword) == 0)
		{
			SetConsoleTextAttribute(hConsoleOut, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			cout << "Correct password.\n";
		}
		else
		{
			SetConsoleTextAttribute(hConsoleOut, FOREGROUND_RED | FOREGROUND_INTENSITY);
			cout << "Invalid password.\n";
		}
	}
	CloseHandle(hConsoleOut);
	return 0;
}